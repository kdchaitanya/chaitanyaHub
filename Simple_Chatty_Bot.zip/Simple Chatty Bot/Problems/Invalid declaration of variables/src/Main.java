public class Main {

    public static void main(String[] args) {

        // Add type to these two variables

       long a = 512_343;
      long  b = 3_431_231;

        System.out.println(a + b);
    }
}