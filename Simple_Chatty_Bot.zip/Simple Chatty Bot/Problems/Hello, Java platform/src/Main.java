public class Main {

    public static void main(String[] args) {

        System.out.print("Hello, ");
        //System.out.print("world");
      //  System.out.print(" and ");
        System.out.print("Java");
        System.out.print(" platform");
    }
}