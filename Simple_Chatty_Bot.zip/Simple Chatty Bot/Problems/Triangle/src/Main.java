import java.util.Scanner;
class Main {
    public static void main(String[] args) {
        // put your code here
        Scanner inputs = new Scanner(System.in);

        int a = inputs.nextInt();
        int b = inputs.nextInt();
        int c = inputs.nextInt();

        if (a + b > c && a + c > b && b + c > a) {
            System.out.println("YES");
        } else {
            System.out.println("NO");
        }
    }
}