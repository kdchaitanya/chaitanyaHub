import java.util.Scanner;
class Main {
    public static void main(String[] args) {
        // put your code here
        Scanner inputs = new Scanner(System.in);

        int n = inputs.nextInt();
        int m = inputs.nextInt();
        int k = inputs.nextInt();

        if (k % n == 0 && k / n < m || k % m == 0 && k / m < n) {
            System.out.println("YES");
        } else {
            System.out.println("NO");
        }
    }
}