import java.util.Scanner;
class Main {
    public static void main(String[] args) {
        // put your code here
        Scanner inputs = new Scanner(System.in);
         int count = -1;
        int value = 1;
         while (value != 0) {
             value = inputs.nextInt();
             count++;
         }
        System.out.println(count);
    }
}