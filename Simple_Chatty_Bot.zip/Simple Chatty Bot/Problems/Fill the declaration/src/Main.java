public class Main {
    public static void main(String[] args) {

        //int a=123456; // Change this line

        System.out.println("123456");
    }
}