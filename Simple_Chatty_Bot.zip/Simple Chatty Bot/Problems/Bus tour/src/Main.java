import java.util.*;

public class Main {
    public static void main(String[] args) {
        // write your code here
        Scanner inputs = new Scanner(System.in);
        int n = inputs.nextInt();
        int noOfBridges = inputs.nextInt();
        boolean flag = false;
        for (int i = 1; i <= noOfBridges; i++) {
            int heightOfBridges = inputs.nextInt();
            if (heightOfBridges > n) {
                continue;
            } else if (heightOfBridges <= n) {
                System.out.println("Will crash on bridge " + i);
                flag = true;
                break;
            }
        }
        if (!flag) {
            System.out.println("Will not crash");
        }
    }
}