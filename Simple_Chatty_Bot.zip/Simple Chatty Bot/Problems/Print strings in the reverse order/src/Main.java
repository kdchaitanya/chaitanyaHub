import java.util.Scanner;

class Main {
    public static void main(String[] args) {
        Scanner inputs = new Scanner(System.in);

        String word1 = inputs.next(); //"Java"
        String word2 = inputs.next(); //"Programming"
        String word3 = inputs.next(); //"Language"
        System.out.println(word3);
        System.out.println(word2);
        System.out.println(word1);
    }
}