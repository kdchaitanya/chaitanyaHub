import java.util.Scanner;
class Main {
    public static void main(String[] args) {
        // put your code here
        Scanner inputs = new Scanner(System.in);
        long n = inputs.nextLong();
        long t = 1L;
        while (t * t <= n) {
            System.out.println(t * t);
            t++;
        }
    }
}