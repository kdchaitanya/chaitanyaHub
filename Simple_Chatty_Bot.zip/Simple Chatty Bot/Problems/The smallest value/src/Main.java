import java.util.Scanner;

class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        Long m = sc.nextLong();
        Long n = 1L;

        while (n <= m) {
            m = m / n;
            n++;
        }
        System.out.println(n);
    }
}