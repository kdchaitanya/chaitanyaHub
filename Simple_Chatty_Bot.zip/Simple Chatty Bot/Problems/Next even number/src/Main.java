import java.util.Scanner;

class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int number = scanner.nextInt();
      //  int cal = (number-1)%2;
        System.out.println((number + 1) % 2 + number + 1);
    }
}