import java.util.Scanner;
class Main {
    public static void main(String[] args) {
        // put your code here
        Scanner inputs = new Scanner(System.in);

        int a = inputs.nextInt();
        int b = inputs.nextInt();
        long product = 1L;
        for (int i = a; i < b; i++) {
            product = product * i;
        }
        System.out.print(product);
    }
}