public class Main {

    public static void main(String[] args) {
       /* int a,b,c;
        a=3;
        b=5;
        c=4;



        System.out.println(a+ " " + b + " " + c);*/
        System.out.println("3 5 4");
    }
}