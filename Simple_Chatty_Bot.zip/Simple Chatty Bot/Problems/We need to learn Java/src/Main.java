class Main {
    public static void main(String[] args) {
        // put your code here
        System.out.println("WE NEED TO");
        System.out.println();
        System.out.println("LEARN JAVA");
        System.out.println();
        System.out.println("AS QUICKLY AS POSSIBLE");
    }
}