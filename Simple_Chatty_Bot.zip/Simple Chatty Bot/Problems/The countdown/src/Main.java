public class Main {

    public static void main(String[] args) {

         System.out.print("three! ");
         System.out.print("two! ");
         System.out.println("one!");
         //System.out.println("go!");


        System.out.println("go!");
    }
}