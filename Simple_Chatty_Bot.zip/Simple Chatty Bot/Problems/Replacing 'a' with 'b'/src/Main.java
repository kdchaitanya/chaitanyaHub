import java.util.Scanner;
class Main {
    public static void main(String[] args) {
        // put your code here
        Scanner input = new Scanner(System.in);
        //String word = input.nextLine();

        System.out.print(input.nextLine().replace("a","b"));

    }
}