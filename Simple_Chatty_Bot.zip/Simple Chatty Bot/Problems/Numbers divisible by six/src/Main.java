import java.util.Scanner;
class Main {
    public static void main(String[] args) {
        // put your code here
        Scanner inputs = new Scanner(System.in);
        int number = inputs.nextInt();
        int sum = 0;
        for (int i = 1; i <= number; i++) {
             int elements = inputs.nextInt();
             if (elements % 6 == 0) {
                 sum = sum + elements;
             }
        }
        System.out.println(sum);
    }
}