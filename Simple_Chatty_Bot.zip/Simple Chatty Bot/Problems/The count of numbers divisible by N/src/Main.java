import java.util.Scanner;
class Main {
    public static void main(String[] args) {
        // put your code here
        Scanner inputs = new Scanner(System.in);

        int a = inputs.nextInt();
        int b = inputs.nextInt();
        int n = inputs.nextInt();
        int count = 0;
        for (int i = a; i <= b; i++) {
            if (i % n == 0) {
                count++;
            }

        }
        System.out.println(count);
    }
}