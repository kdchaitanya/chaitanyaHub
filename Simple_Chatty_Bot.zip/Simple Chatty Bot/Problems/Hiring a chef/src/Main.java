import java.util.Scanner;
class Main {
    public static void main(String[] args) {
        Scanner inputs = new Scanner(System.in);
        String firstName = inputs.next();
        inputs.next();
        inputs.next();
        inputs.next();
        String cuisinePref = inputs.next();
        System.out.println("The form for " + firstName + " is completed. " +
                "We will contact you if we need a chef that cooks "
                + cuisinePref + " dishes.");
    }
}