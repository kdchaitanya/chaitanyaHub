import java.util.Scanner;

class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        // put your code here
        int peanutButterCups = scanner.nextInt();
        boolean weekend = scanner.nextBoolean();
        boolean result1 = peanutButterCups >= 10 && peanutButterCups <= 20 && !weekend;
        boolean result2 =  peanutButterCups >= 15 && peanutButterCups <= 25 && weekend;
        System.out.println(result1 || result2);
    }
}