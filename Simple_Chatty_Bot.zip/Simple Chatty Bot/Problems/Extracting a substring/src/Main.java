import java.util.Scanner;
class Main {
    public static void main(String[] args) {

        Scanner inputs = new Scanner(System.in);
        String word = inputs.next();
        int start = inputs.nextInt();
        int end = inputs.nextInt();
        String result = word.substring(start,end+1);
        System.out.println(result);
    }
}