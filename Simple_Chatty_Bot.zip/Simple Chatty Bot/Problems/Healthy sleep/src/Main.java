import java.util.Scanner;
class Main {
    public static void main(String[] args) {
        // put your code here
        Scanner inputs = new Scanner(System.in);

        int recommendedSleeps = inputs.nextInt(); // 7
        int overSleeps = inputs.nextInt(); // 9
        int totalSleeps = inputs.nextInt(); // 10


            if (totalSleeps <= overSleeps && totalSleeps >= recommendedSleeps) {
                System.out.println("Normal");
            } else if (totalSleeps >= overSleeps && totalSleeps >= recommendedSleeps) {
                System.out.println("Excess");
            } else if (totalSleeps <= overSleeps && totalSleeps <= recommendedSleeps) {
                System.out.println("Deficiency");
            }

    }
}