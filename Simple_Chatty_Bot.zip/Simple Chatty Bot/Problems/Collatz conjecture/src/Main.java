import java.util.Scanner;
class Main {
    public static void main(String[] args) {
        // put your code here
        Scanner inputs = new Scanner(System.in);

        int n = inputs.nextInt();
        System.out.print(n + " ");
        while (n != 1) {
            if (n % 2 == 0) {
                System.out.print(n / 2 + " ");
                n = n / 2;
            } else {
                System.out.print(n * 3 + 1 + " ");
                n = n * 3 + 1;
            }

        }
    }
}