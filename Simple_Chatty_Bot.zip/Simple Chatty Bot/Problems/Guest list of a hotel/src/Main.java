//put imports you need here

import java.util.Scanner;


class Main {
    public static void main(String[] args) {
        // put your code here
        Scanner inputs = new Scanner(System.in);
        //room1
        String word1 = inputs.next();
        String word2 = inputs.next();
        String word3 = inputs.next();
        //room2
        String word4 = inputs.next();
        String word5 = inputs.next();
        String word6 = inputs.next();
        //room3
        String word7 = inputs.next();
        String word8 = inputs.next();
      //  String word9 = inputs.next();

     //   System.out.println(word9);
        System.out.println(word8);
        System.out.println(word7);
        System.out.println(word6);
        System.out.println(word5);
        System.out.println(word4);
        System.out.println(word3);
        System.out.println(word2);
        System.out.println(word1);



    }
}