import java.util.Scanner;
class Main {
    public static void main(String[] args) {
        // put your code here
        Scanner inputs = new Scanner(System.in);
        String word1 = inputs.nextLine();
        String word2 = inputs.nextLine();
        System.out.println(word1.replace(" ","").equals(word2.replace(" ","")));
    }
}