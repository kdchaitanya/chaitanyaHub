class Main {
    public static void main(String[] args) {
        // put your code here
        System.out.println(0);
        System.out.println(1);
        System.out.println(2);
        System.out.println(3);
        System.out.println(4);
    }
}
