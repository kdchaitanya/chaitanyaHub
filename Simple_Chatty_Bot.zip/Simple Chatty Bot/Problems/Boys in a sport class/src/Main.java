import java.util.Scanner;

class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        // put your code here
        int h1 = scanner.nextInt(); // 165
        int h2 = scanner.nextInt(); // 161
        int h3 = scanner.nextInt(); // 158

        boolean result1 = h1 >= h2 && h2 >= h3;
        boolean result2 = h1 <= h2 && h2 <= h3;

        System.out.println(result1 || result2);

    }
}