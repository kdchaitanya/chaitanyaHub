import java.util.Scanner;
class Main {
    public static void main(String[] args) {
        // put your code here
        Scanner inputs = new Scanner(System.in);
        while (inputs.hasNextInt())  {
            int n = inputs.nextInt();
            if (n == 0) {
                break;
            }
            if (n % 2 == 0) {
                System.out.println("even");
            } else {
                System.out.println("odd");
            }
        }
    }
}