import java.util.Scanner;
class Main {
    public static void main(String[] args) {
        // put your code here
        Scanner inputs = new Scanner(System.in);
        int n = inputs.nextInt();
        int count = 1;
        for (int i = 1; i <= n; i++) {
                for (int k = 1; k <= i; k++) {
                    if (count > n) { // Breaking if n more than count.
                        break;
                    }
                    if (count <= n) { // Prints only n times.
                        System.out.print(i + " ");
                        count++;
                    }
                }
            }
        }
    }
