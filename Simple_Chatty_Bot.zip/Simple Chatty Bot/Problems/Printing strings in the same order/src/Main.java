import java.util.Scanner;

class Main {
    public static void main(String[] args) {
        // put your code here
        Scanner inputs = new Scanner(System.in);
        String word1 = inputs.next();
        String word2 = inputs.next();
        String word3 = inputs.next();
        String word4 = inputs.next();

        System.out.println(word1);
        System.out.println(word2);
        System.out.println(word3);
        System.out.println(word4);


    }
}